package com.example.mtmyschool
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.mtmyschool.databinding.ActivityregistroBinding

class RegistroActivity: AppCompatActivity(){
    lateinit var binding: ActivityregistroBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityregistroBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}